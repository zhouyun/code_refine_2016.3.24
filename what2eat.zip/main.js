// maze
// $(document).on("click","#play",function(){
// 	$("#mazevimg").hide();
// 	$("#play").hide();
// })
// //pushtimer
// $("#next").hover(function(){
// 	$(this).removeClass('next').addClass('next_hover');
// },function(){
// 	$(this).removeClass('next_hover').addClass('next');
// });

// $(".title").click(function(){
// 	$(this).hide();
// })
